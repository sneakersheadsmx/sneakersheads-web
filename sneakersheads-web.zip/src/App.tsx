import React, { useState, useEffect } from "react";
import {
  ShoppingBag,
  X,
  Instagram,
  Menu,
  ArrowRight,
  Search,
  User,
  Mail,
  MessageSquare,
  ChevronDown,
  Check,
  SlidersHorizontal,
  MapPin,
  Truck,
  Lock,
  CreditCard,
} from "lucide-react";

// Icono Oficial de WhatsApp en SVG (Reemplaza a MessageSquare)
const WhatsAppIcon = ({ className, onClick }) => (
  <svg
    className={className}
    onClick={onClick}
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="currentColor"
  >
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51a12.8 12.8 0 0 0-.57-.01c-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413z" />
  </svg>
);

const BRANDS = [
  "Adidas",
  "Air Jordan",
  "Alexander McQueen",
  "Alo",
  "Amiri",
  "Asics",
  "Balenciaga",
  "Birkenstock",
  "Dior",
  "Dolce & Gabbana",
  "Ferragamo",
  "Golden Goose",
  "Hoka",
  "Louboutin",
  "Louis Vuitton",
  "Maison Margiela",
  "New Balance",
  "Off-White",
  "On",
  "Onitsuka",
  "UGG",
  "Valentino",
  "Veja",
  "Yeezy",
  "Zegna",
];

const SNEAKERS_DB = [
  {
    id: 1,
    brand: "Air Jordan",
    name: 'Air Jordan 4 Retro "Military Black"',
    price: 6500,
    image:
      "https://images.unsplash.com/photo-1595908129746-5741f520b8fa?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    status: "available",
    color: "Blanco",
    gender: "Hombre",
    style: "High",
  },
  {
    id: 2,
    brand: "Yeezy",
    name: 'Yeezy Boost 350 V2 "Onyx"',
    price: 5200,
    image:
      "https://images.unsplash.com/photo-1628413993904-94ecb60f1239?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    status: "available",
    color: "Negro",
    gender: "Unisex",
    style: "Low",
  },
  {
    id: 3,
    brand: "Dior",
    name: "B23 High Top Logo Oblique",
    price: 22800,
    image:
      "https://images.unsplash.com/photo-1595461135849-bf08893fdc2c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    status: "available",
    color: "Blanco",
    gender: "Hombre",
    style: "High",
  },
  {
    id: 4,
    brand: "Off-White",
    name: 'Out Of Office "Ooo" Sneakers',
    price: 11500,
    image:
      "https://images.unsplash.com/photo-1608231387042-66d1773070a5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    status: "sold_out",
    color: "Blanco",
    gender: "Hombre",
    style: "Low",
  },
  {
    id: 5,
    brand: "New Balance",
    name: '550 "White Grey"',
    price: 3200,
    image:
      "https://images.unsplash.com/photo-1539185441755-769473a23570?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    status: "available",
    color: "Gris",
    gender: "Mujer",
    style: "Low",
  },
  {
    id: 6,
    brand: "Balenciaga",
    name: "Triple S Clear Sole",
    price: 19400,
    image:
      "https://images.unsplash.com/photo-1511556532299-8f662fc26c06?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    status: "available",
    color: "Negro",
    gender: "Unisex",
    style: "Chunky",
  },
  {
    id: 7,
    brand: "Adidas",
    name: 'Campus 00s "Core Black"',
    price: 2400,
    image:
      "https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    status: "available",
    color: "Negro",
    gender: "Unisex",
    style: "Low",
  },
  {
    id: 8,
    brand: "On",
    name: 'Cloudmonster "Luminary"',
    price: 3800,
    image:
      "https://images.unsplash.com/photo-1552346154-21d32810baa3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    status: "available",
    color: "Gris",
    gender: "Mujer",
    style: "Running",
  },
  {
    id: 9,
    brand: "Alexander McQueen",
    name: "Oversized Sneaker White Black",
    price: 9800,
    image:
      "https://images.unsplash.com/photo-1608231387042-66d1773070a5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    status: "available",
    color: "Blanco",
    gender: "Unisex",
    style: "Luxury",
  },
  {
    id: 10,
    brand: "Alo",
    name: "Alo x Future High-Top",
    price: 4500,
    image:
      "https://images.unsplash.com/photo-1595908129746-5741f520b8fa?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    status: "available",
    color: "Blanco",
    gender: "Unisex",
    style: "Lifestyle",
  },
  {
    id: 11,
    brand: "Amiri",
    name: "Skeleton Low Top Black",
    price: 12500,
    image:
      "https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    status: "available",
    color: "Negro",
    gender: "Hombre",
    style: "Low",
  },
  {
    id: 12,
    brand: "Asics",
    name: "Gel-Kayano 14 Cream Black",
    price: 3900,
    image:
      "https://images.unsplash.com/photo-1552346154-21d32810baa3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    status: "available",
    color: "Plata",
    gender: "Unisex",
    style: "Running",
  },
  {
    id: 13,
    brand: "Birkenstock",
    name: "Boston Shearling Mink",
    price: 4200,
    image:
      "https://images.unsplash.com/photo-1539185441755-769473a23570?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    status: "available",
    color: "Café",
    gender: "Unisex",
    style: "Clog",
  },
  {
    id: 14,
    brand: "Dolce & Gabbana",
    name: "Daymaster Sneaker Logo",
    price: 11000,
    image:
      "https://images.unsplash.com/photo-1595461135849-bf08893fdc2c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    status: "available",
    color: "Blanco",
    gender: "Hombre",
    style: "Chunky",
  },
  {
    id: 15,
    brand: "Ferragamo",
    name: "Gancini Runner Black",
    price: 13500,
    image:
      "https://images.unsplash.com/photo-1511556532299-8f662fc26c06?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    status: "available",
    color: "Negro",
    gender: "Hombre",
    style: "Runner",
  },
  {
    id: 16,
    brand: "Golden Goose",
    name: "Super-Star Classic Handcrafted",
    price: 8900,
    image:
      "https://images.unsplash.com/photo-1608231387042-66d1773070a5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    status: "available",
    color: "Blanco",
    gender: "Unisex",
    style: "Vintage",
  },
  {
    id: 17,
    brand: "Hoka",
    name: "Bonki X Clifton L Suede",
    price: 4100,
    image:
      "https://images.unsplash.com/photo-1552346154-21d32810baa3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    status: "available",
    color: "Beige",
    gender: "Unisex",
    style: "Running",
  },
  {
    id: 18,
    brand: "Louboutin",
    name: "Louis Junior Spikes Orlato",
    price: 18500,
    image:
      "https://images.unsplash.com/photo-1595461135849-bf08893fdc2c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    status: "available",
    color: "Negro",
    gender: "Hombre",
    style: "Luxury",
  },
  {
    id: 19,
    brand: "Louis Vuitton",
    name: "Trainer Sneaker White Green",
    price: 26500,
    image:
      "https://images.unsplash.com/photo-1595908129746-5741f520b8fa?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    status: "available",
    color: "Blanco",
    gender: "Hombre",
    style: "High",
  },
  {
    id: 20,
    brand: "Maison Margiela",
    name: "Replica Paint Drop Sneaker",
    price: 14200,
    image:
      "https://images.unsplash.com/photo-1539185441755-769473a23570?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    status: "available",
    color: "Multicolor",
    gender: "Unisex",
    style: "Low",
  },
  {
    id: 21,
    brand: "Onitsuka",
    name: "Mexico 66 Yellow Black",
    price: 2900,
    image:
      "https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    status: "available",
    color: "Amarillo",
    gender: "Unisex",
    style: "Retro",
  },
  {
    id: 22,
    brand: "UGG",
    name: "Tasman Slipper Chestnut",
    price: 3100,
    image:
      "https://images.unsplash.com/photo-1628413993904-94ecb60f1239?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    status: "available",
    color: "Café",
    gender: "Mujer",
    style: "Slipper",
  },
  {
    id: 23,
    brand: "Valentino",
    name: "One Stud Low Top Sneaker",
    price: 13200,
    image:
      "https://images.unsplash.com/photo-1595461135849-bf08893fdc2c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    status: "available",
    color: "Blanco",
    gender: "Unisex",
    style: "Luxury",
  },
  {
    id: 24,
    brand: "Veja",
    name: "Campo Extra White Black",
    price: 3400,
    image:
      "https://images.unsplash.com/photo-1539185441755-769473a23570?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    status: "available",
    color: "Blanco",
    gender: "Unisex",
    style: "Eco",
  },
  {
    id: 25,
    brand: "Zegna",
    name: "Triple Stitch Luxury Leather",
    price: 15500,
    image:
      "https://images.unsplash.com/photo-1511556532299-8f662fc26c06?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    status: "available",
    color: "Azul",
    gender: "Hombre",
    style: "SlipOn",
  },
];

const SIZES_MX = ["25", "25.5", "26", "26.5", "27", "27.5", "28", "28.5", "29"];

const MEXICO_STATES = [
  "Aguascalientes",
  "Baja California",
  "Baja California Sur",
  "Campeche",
  "Chiapas",
  "Chihuahua",
  "Ciudad de México",
  "Coahuila",
  "Colima",
  "Durango",
  "Estado de México",
  "Guanajuato",
  "Guerrero",
  "Hidalgo",
  "Jalisco",
  "Michoacán",
  "Morelos",
  "Nayarit",
  "Nuevo León",
  "Oaxaca",
  "Puebla",
  "Querétaro",
  "Quintana Roo",
  "San Luis Potosí",
  "Sinaloa",
  "Sonora",
  "Tabasco",
  "Tamaulipas",
  "Tlaxcala",
  "Veracruz",
  "Yucatán",
  "Zacatecas",
];

const MEXICO_CITIES_BY_STATE = {
  Aguascalientes: [
    "Aguascalientes",
    "Jesús María",
    "Calvillo",
    "Rincón de Romos",
    "Pabellón de Arteaga",
  ],
  "Baja California": [
    "Tijuana",
    "Mexicali",
    "Ensenada",
    "Playas de Rosarito",
    "Tecate",
    "San Quintín",
    "San Felipe",
  ],
  "Baja California Sur": [
    "La Paz",
    "Los Cabos",
    "Cabo San Lucas",
    "San José del Cabo",
    "Loreto",
    "Comondú",
    "Mulegé",
  ],
  Campeche: [
    "Campeche",
    "Ciudad del Carmen",
    "Champotón",
    "Escárcega",
    "Calkiní",
  ],
  Chiapas: [
    "Tuxtla Gutiérrez",
    "San Cristóbal de las Casas",
    "Tapachula",
    "Comitán de Domínguez",
    "Palenque",
    "Chiapa de Corzo",
  ],
  Chihuahua: [
    "Chihuahua",
    "Ciudad Juárez",
    "Delicias",
    "Cuauhtémoc",
    "Hidalgo del Parral",
    "Nuevo Casas Grandes",
  ],
  "Ciudad de México": [
    "Álvaro Obregón",
    "Azcapotzalco",
    "Benito Juárez",
    "Coyoacán",
    "Cuajimalpa",
    "Cuauhtémoc",
    "Gustavo A. Madero",
    "Iztacalco",
    "Iztapalapa",
    "Magdalena Contreras",
    "Miguel Hidalgo",
    "Milpa Alta",
    "Tláhuac",
    "Tlalpan",
    "Venustiano Carranza",
    "Xochimilco",
  ],
  Coahuila: [
    "Saltillo",
    "Torreón",
    "Monclova",
    "Piedras Negras",
    "Acuña",
    "Ramos Arizpe",
    "Parras",
  ],
  Colima: ["Colima", "Manzanillo", "Tecomán", "Villa de Álvarez", "Comala"],
  Durango: ["Durango", "Gómez Palacio", "Lerdo", "Santiago Papasquiaro"],
  "Estado de México": [
    "Toluca",
    "Naucalpan de Juárez",
    "Tlalnepantla de Baz",
    "Huixquilucan",
    "Metepec",
    "Ecatepec de Morelos",
    "Atizapán de Zaragoza",
    "Cuautitlán Izcalli",
    "Nezahualcóyotl",
    "Texcoco",
    "Valle de Bravo",
  ],
  Guanajuato: [
    "León",
    "Irapuato",
    "Celaya",
    "Guanajuato",
    "Salamanca",
    "San Miguel de Allende",
    "Silao",
  ],
  Guerrero: [
    "Acapulco de Juárez",
    "Chilpancingo de los Bravo",
    "Zihuatanejo",
    "Iguala",
    "Taxco de Alarcón",
  ],
  Hidalgo: [
    "Pachuca de Soto",
    "Mineral de la Reforma",
    "Tulancingo",
    "Tula de Allende",
    "Tepeji del Río",
  ],
  Jalisco: [
    "Guadalajara",
    "Zapopan",
    "San Pedro Tlaquepaque",
    "Tonalá",
    "Tlajomulco de Zúñiga",
    "Puerto Vallarta",
    "Tepatitlán",
    "Lagos de Moreno",
  ],
  Michoacán: [
    "Morelia",
    "Uruapan",
    "Zamora",
    "Lázaro Cárdenas",
    "Pátzcuaro",
    "Zitácuaro",
  ],
  Morelos: [
    "Cuernavaca",
    "Jiutepec",
    "Cuautla",
    "Temixco",
    "Tepoztlán",
    "Yautepec",
  ],
  Nayarit: [
    "Tepic",
    "Bahía de Banderas",
    "Nuevo Vallarta",
    "Sayulita",
    "Compostela",
    "Santiago Ixcuintla",
  ],
  "Nuevo León": [
    "Monterrey",
    "San Pedro Garza García",
    "San Nicolás de los Garza",
    "Guadalupe",
    "Apodaca",
    "Santa Catarina",
    "Escobedo",
    "Santiago",
  ],
  Oaxaca: [
    "Oaxaca de Juárez",
    "Salina Cruz",
    "Juchitán de Zaragoza",
    "Puerto Escondido",
    "Huatulco",
    "Tuxtepec",
  ],
  Puebla: [
    "Puebla",
    "San Andrés Cholula",
    "San Pedro Cholula",
    "Tehuacán",
    "Atlixco",
    "San Martín Texmelucan",
    "Teziutlán",
    "Huauchinango",
  ],
  Querétaro: [
    "Querétaro",
    "Corregidora",
    "El Marqués",
    "San Juan del Río",
    "Tequisquiapan",
  ],
  "Quintana Roo": [
    "Cancún (Benito Juárez)",
    "Playa del Carmen (Solidaridad)",
    "Tulum",
    "Chetumal (Othón P. Blanco)",
    "Cozumel",
    "Isla Mujeres",
  ],
  "San Luis Potosí": [
    "San Luis Potosí",
    "Soledad de Graciano Sánchez",
    "Ciudad Valles",
    "Matehuala",
    "Rioverde",
  ],
  Sinaloa: [
    "Culiacán",
    "Mazatlán",
    "Los Mochis (Ahome)",
    "Guasave",
    "Guamúchil",
  ],
  Sonora: [
    "Hermosillo",
    "Ciudad Obregón (Cajeme)",
    "Nogales",
    "San Luis Río Colorado",
    "Guaymas",
    "Puerto Peñasco",
    "Navojoa",
  ],
  Tabasco: [
    "Villahermosa (Centro)",
    "Cárdenas",
    "Comalcalco",
    "Macuspana",
    "Paraíso",
  ],
  Tamaulipas: [
    "Reynosa",
    "Matamoros",
    "Nuevo Laredo",
    "Tampico",
    "Ciudad Victoria",
    "Ciudad Madero",
    "Altamira",
  ],
  Tlaxcala: [
    "Tlaxcala",
    "Apizaco",
    "Huamantla",
    "Chiautempan",
    "San Pablo del Monte",
  ],
  Veracruz: [
    "Veracruz",
    "Boca del Río",
    "Xalapa",
    "Coatzacoalcos",
    "Córdoba",
    "Orizaba",
    "Poza Rica",
    "Tuxpan",
  ],
  Yucatán: ["Mérida", "Valladolid", "Progreso", "Tizimín", "Kanasín", "Umán"],
  Zacatecas: ["Zacatecas", "Guadalupe", "Fresnillo", "Jerez", "Río Grande"],
};

const MARQUEE_LOGOS = [
  {
    brand: "Valentino",
    img: "https://assets.stickpng.com/images/61487f4bd329bb0004dbd33b.png",
  },
  {
    brand: "Golden Goose",
    img: "https://images.seeklogo.com/logo-png/47/1/golden-goose-logo-png_seeklogo-474536.png",
  },
  {
    brand: "Dior",
    img: "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a8/Dior_Logo.svg/3840px-Dior_Logo.svg.png",
  },
  { brand: "Alo", img: "https://centrosantafe.com.mx/cdn/shop/files/1730.png" },
  {
    brand: "On",
    img: "https://images.seeklogo.com/logo-png/43/1/on-logo-png_seeklogo-439325.png",
  },
  {
    brand: "Alexander McQueen",
    img: "https://1000marcas.net/wp-content/uploads/2020/03/Logo-McQ-Alexander-McQueen.png",
  },
  {
    brand: "Air Jordan",
    img: "https://upload.wikimedia.org/wikipedia/en/3/37/Jumpman_logo.svg",
  },
];

export default function SneakersheadsStore() {
  const [activePage, setActivePage] = useState("home");
  const [activeBrand, setActiveBrand] = useState(null);

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const [isCartOpen, setIsCartOpen] = useState(false);
  const [cart, setCart] = useState([]);

  const [selectedProduct, setSelectedProduct] = useState(null);
  const [selectedSize, setSelectedSize] = useState(null);
  const [notification, setNotification] = useState(null);

  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);

  const [openFaq, setOpenFaq] = useState(null);

  const [shippingMethod, setShippingMethod] = useState("delivery");
  const [paymentMethod, setPaymentMethod] = useState("card");

  const [sortBy, setSortBy] = useState("default");
  const [isFilterDropdownOpen, setIsFilterDropdownOpen] = useState(false);
  const [isFilterMenuOpen, setIsFilterMenuOpen] = useState(false);

  const [selectedColors, setSelectedColors] = useState([]);
  const [selectedGenders, setSelectedGenders] = useState([]);
  const [selectedStyles, setSelectedStyles] = useState([]);

  const availableColors = [...new Set(SNEAKERS_DB.map((item) => item.color))];
  const availableGenders = [...new Set(SNEAKERS_DB.map((item) => item.gender))];
  const availableStyles = [...new Set(SNEAKERS_DB.map((item) => item.style))];

  const [zipCode, setZipCode] = useState("");
  const [phoneNum, setPhoneNum] = useState("");
  const [selectedState, setSelectedState] = useState("");
  const [selectedCity, setSelectedCity] = useState("");
  const [cardNumber, setCardNumber] = useState("");
  const [cardName, setCardName] = useState("");
  const [cardExpiry, setCardExpiry] = useState("");
  const [cardCvv, setCardCvv] = useState("");

  const getCitiesForSelectedState = () => {
    if (!selectedState) return [];
    const normalized = selectedState.trim().toLowerCase();
    const matchedKey = Object.keys(MEXICO_CITIES_BY_STATE).find(
      (key) => key.toLowerCase() === normalized
    );
    return matchedKey ? MEXICO_CITIES_BY_STATE[matchedKey] : [];
  };

  const whatsappHelpMessage = encodeURIComponent(
    "¡Hola SNEAKERSHEADS! 👋 Tengo una duda sobre..."
  );
  const whatsappHelpUrl = `https://wa.me/526461997001?text=${whatsappHelpMessage}`;

  const handleSearchSubmit = (e) => {
    if (e.key === "Enter") {
      setActivePage("marcas");
      setActiveBrand(null); // Al buscar general, quitamos el filtro de una sola marca
      setIsSearchOpen(false);
      window.scrollTo(0, 0);
    }
  };

  const handleImgError = (e) => {
    e.target.onerror = null;
    e.target.src =
      "https://images.unsplash.com/photo-1542291026-7eec264c27ff?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80";
  };

  useEffect(() => {
    if (shippingMethod === "delivery" && paymentMethod === "cash") {
      setPaymentMethod("card");
    }
  }, [shippingMethod, paymentMethod]);

  const subtotal = cart.reduce((sum, item) => sum + item.price, 0);
  const shippingCost =
    shippingMethod === "delivery" && subtotal < 5000 && subtotal > 0 ? 250 : 0;
  const finalTotal = subtotal + shippingCost;

  const handleAddToCart = () => {
    if (!selectedSize) return;
    setCart([...cart, { ...selectedProduct, selectedSize }]);
    setNotification(`Agregaste ${selectedProduct.name} al carrito`);
    setSelectedProduct(null);
    setSelectedSize(null);
    setIsCartOpen(true);
    setTimeout(() => setNotification(null), 3000);
  };

  const removeFromCart = (indexToRemove) =>
    setCart(cart.filter((_, index) => index !== indexToRemove));

  const goToCheckout = () => {
    setIsCartOpen(false);
    setActivePage("checkout");
    window.scrollTo(0, 0);
  };

  const handleCheckout = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const fullName = `${formData.get("firstName")} ${formData.get("lastName")}`;
    let itemsText = cart
      .map(
        (item) =>
          `- 1x ${item.brand} ${item.name} (Talla: ${
            item.selectedSize
          }) - $${item.price.toLocaleString("es-MX")}`
      )
      .join("\n");
    let deliveryText =
      shippingMethod === "delivery"
        ? `A Domicilio 🚚\n📍 Dirección: ${formData.get(
            "street"
          )}, ${formData.get("colony")}, CP ${formData.get(
            "zip"
          )}, ${formData.get("city")}, ${formData.get("state")}`
        : "Entrega Personal 🤝";
    let paymentText =
      paymentMethod === "card"
        ? "Tarjeta 💳"
        : paymentMethod === "paypal"
        ? "PayPal 🌐"
        : "Efectivo 💵";
    let total = finalTotal;
    let message = `¡Hola Sneakersheads! 👟 Nuevo pedido de: ${fullName}\n\n📦 MI CARRITO:\n${itemsText}\n\n🚚 ENTREGA: ${deliveryText}\n💳 PAGO: ${paymentText}\n💰 TOTAL: $${total.toLocaleString(
      "es-MX"
    )} MXN\n\n👤 MIS DATOS:\nNombre: ${fullName}\nTeléfono: ${formData.get(
      "phone"
    )}\nCorreo: ${formData.get("email")}`;

    const whatsappNumber = "526461997001";
    const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(
      message
    )}`;

    setIsCheckingOut(true);
    setTimeout(() => {
      setIsCheckingOut(false);
      if (shippingMethod === "personal") window.open(whatsappUrl, "_blank");
      setPaymentSuccess(true);
      setTimeout(() => {
        setPaymentSuccess(false);
        setCart([]);
        setActivePage("home");
        window.scrollTo(0, 0);
      }, 4000);
    }, 1500);
  };

  const goToHome = () => {
    setActivePage("home");
    setActiveBrand(null);
    setIsMobileMenuOpen(false);
    window.scrollTo(0, 0);
  };
  const goToMarcas = () => {
    setActivePage("marcas");
    setActiveBrand(null);
    setIsMobileMenuOpen(false);
    window.scrollTo(0, 0);
  };
  const goToBrand = (brand) => {
    setActivePage("marcas");
    setActiveBrand(brand);
    setIsMobileMenuOpen(false);
    window.scrollTo(0, 0);
  };

  const getFilteredProducts = () => {
    let list = SNEAKERS_DB.filter((item) => {
      const matchBrand = activeBrand ? item.brand === activeBrand : true;
      const searchLower = searchQuery.toLowerCase().trim();

      // Búsqueda inteligente: filtra si la búsqueda está en nombre, marca, color o estilo
      const matchSearch = searchLower
        ? item.name.toLowerCase().includes(searchLower) ||
          item.brand.toLowerCase().includes(searchLower) ||
          item.color.toLowerCase().includes(searchLower) ||
          item.style.toLowerCase().includes(searchLower)
        : true;

      const matchColor =
        selectedColors.length === 0 || selectedColors.includes(item.color);
      const matchGender =
        selectedGenders.length === 0 || selectedGenders.includes(item.gender);
      const matchStyle =
        selectedStyles.length === 0 || selectedStyles.includes(item.style);

      return (
        matchBrand && matchSearch && matchColor && matchGender && matchStyle
      );
    });

    if (sortBy === "price_asc") {
      list.sort((a, b) => a.price - b.price);
    } else if (sortBy === "price_desc") {
      list.sort((a, b) => b.price - a.price);
    } else if (sortBy === "available") {
      list.sort((a, b) => (a.status === "available" ? -1 : 1));
    }
    return list;
  };

  const handleToggleFilter = (setState, state, value) => {
    if (state.includes(value)) setState(state.filter((item) => item !== value));
    else setState([...state, value]);
  };

  const FilterAccordion = ({ title, options, selected, onChange }) => {
    const [isOpen, setIsOpen] = useState(true);
    return (
      <div className="border-b border-gray-200 py-5">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="w-full flex justify-between items-center text-xs font-bold tracking-widest uppercase text-black mb-1 hover:text-gray-600 transition-colors"
        >
          {title}
          <ChevronDown
            className={`w-4 h-4 transition-transform ${
              isOpen ? "rotate-180" : ""
            }`}
          />
        </button>
        <div
          className={`flex flex-col gap-4 overflow-hidden transition-all duration-300 ease-in-out ${
            isOpen ? "max-h-[500px] mt-4 opacity-100" : "max-h-0 opacity-0"
          }`}
        >
          {options.map((opt) => (
            <label
              key={opt}
              className="flex items-center gap-3 cursor-pointer group"
            >
              <input
                type="checkbox"
                checked={selected.includes(opt)}
                onChange={() => onChange(opt)}
                className="w-4 h-4 accent-black border-gray-300 rounded-sm cursor-pointer"
              />
              <span className="text-sm text-gray-600 group-hover:text-black transition-colors">
                {opt}
              </span>
            </label>
          ))}
        </div>
      </div>
    );
  };

  const faqs = [
    {
      q: "¿Cómo encuentro un producto específico?",
      a: "Usa nuestra barra de búsqueda inteligente en la parte superior o navega directamente por la sección de Marcas para ver los pares agrupados por casa de diseño.",
    },
    {
      q: "¿Qué métodos de pago aceptan?",
      a: "Aceptamos tarjetas de crédito y débito con encriptación bancaria, pagos seguros mediante PayPal, y si eliges 'Entrega Personal', cuentas con la opción de pagar en efectivo contra entrega.",
    },
    {
      q: "¿Es seguro pagar con tarjeta en la tienda?",
      a: "Tu seguridad es absoluta. Toda la tienda cuenta con certificados SSL y pasarelas de pago blindadas con tecnología internacional. Jamás almacenamos los datos sensibles de tu tarjeta.",
    },
    {
      q: "¿Cuánto cuesta el envío y cuánto tarda?",
      a: "Realizamos envíos asegurados a todo México. Dependiendo de tu ubicación, recibirás tu paquete en la puerta de tu hogar en un lapso de 4 a 7 días hábiles.",
    },
    {
      q: "¿Mandan mensajes o avisos cuando despachan el pedido?",
      a: "Sí, te enviaremos tu guía de rastreo y actualizaciones en tiempo real por correo electrónico y WhatsApp en cuanto tu paquete salga de nuestra bóveda.",
    },
  ];

  return (
    <div className="min-h-screen bg-white font-sans text-gray-900 selection:bg-black selection:text-white flex flex-col">
      <style>{`
        @keyframes marquee { 0% { transform: translateX(0%); } 100% { transform: translateX(-50%); } }
        .animate-marquee { display: flex; width: max-content; animation: marquee 35s linear infinite; gap: 4rem; }
        .animate-marquee:hover { animation-play-state: paused; }
        .bg-texture-dots { background-color: #ffffff; background-image: radial-gradient(#e5e7eb 1px, transparent 1px); background-size: 20px 20px; }
      `}</style>

      {/* HEADER */}
      <header className="sticky top-0 z-40 w-full bg-white border-b border-gray-100 flex flex-col transition-all duration-300">
        <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 h-16 sm:h-20 flex items-center justify-between w-full">
          <div className="flex items-center gap-4 lg:w-1/3">
            <Menu
              className="w-6 h-6 cursor-pointer lg:hidden"
              onClick={() => setIsMobileMenuOpen(true)}
            />
            <Search
              className="w-5 h-5 cursor-pointer hidden lg:block hover:text-gray-500"
              onClick={() => setIsSearchOpen(!isSearchOpen)}
            />
          </div>

          <div
            className="lg:w-1/3 flex justify-center cursor-pointer"
            onClick={goToHome}
          >
            <h1 className="text-3xl font-black tracking-tighter uppercase text-black">
              SNEAKERSHEADS
            </h1>
          </div>

          <div className="flex items-center justify-end gap-6 lg:w-1/3">
            <Search
              className="w-5 h-5 cursor-pointer lg:hidden"
              onClick={() => setIsSearchOpen(!isSearchOpen)}
            />
            <User className="w-5 h-5 cursor-pointer hidden sm:block hover:text-gray-500" />
            <div
              className="relative cursor-pointer group"
              onClick={() => setIsCartOpen(true)}
            >
              <ShoppingBag className="w-5 h-5 group-hover:text-gray-500 transition-colors" />
              {cart.length > 0 && (
                <span className="absolute -top-2 -right-2 bg-black text-white text-[10px] font-bold h-4 w-4 rounded-full flex items-center justify-center">
                  {cart.length}
                </span>
              )}
            </div>
          </div>
        </div>

        <div className="hidden lg:flex justify-center items-center h-12 gap-8 text-[11px] font-bold tracking-[0.2em] uppercase bg-white">
          <button
            onClick={goToHome}
            className={`${
              activePage === "home"
                ? "border-b-2 border-black"
                : "text-gray-500"
            } hover:text-black pb-1 transition-colors`}
          >
            inicio
          </button>
          <button
            onClick={() => {
              setActivePage("conocenos");
              setActiveBrand(null);
            }}
            className={`${
              activePage === "conocenos"
                ? "border-b-2 border-black"
                : "text-gray-500"
            } hover:text-black pb-1 transition-colors`}
          >
            conocenos
          </button>
          <button
            onClick={goToMarcas}
            className={`${
              activePage === "marcas" && !activeBrand
                ? "border-b-2 border-black"
                : "text-gray-500"
            } hover:text-black pb-1 transition-colors`}
          >
            marcas
          </button>
          <button
            onClick={() => {
              setActivePage("contactanos");
              setActiveBrand(null);
            }}
            className={`${
              activePage === "contactanos"
                ? "border-b-2 border-black"
                : "text-gray-500"
            } hover:text-black pb-1 transition-colors`}
          >
            contactanos
          </button>
        </div>

        {isSearchOpen && (
          <div className="absolute top-full left-0 w-full bg-white border-b border-gray-100 p-6 shadow-sm z-50">
            <div className="max-w-2xl mx-auto relative">
              <input
                type="text"
                placeholder="Buscar tenis, marcas, colores..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={handleSearchSubmit}
                className="w-full text-2xl font-light border-b-2 border-black py-2 focus:outline-none placeholder-gray-300"
                autoFocus
              />
              <X
                className="absolute right-0 top-3 w-6 h-6 cursor-pointer text-gray-400 hover:text-black"
                onClick={() => setIsSearchOpen(false)}
              />
            </div>
          </div>
        )}
      </header>

      {}
      <div
        className={`fixed inset-0 z-50 transition-opacity duration-300 ${
          isMobileMenuOpen ? "opacity-100 visible" : "opacity-0 invisible"
        }`}
      >
        <div
          className="absolute inset-0 bg-black/70 backdrop-blur-sm"
          onClick={() => setIsMobileMenuOpen(false)}
        />
        <div
          className={`absolute top-0 left-0 bottom-0 w-[85%] max-w-sm bg-[#F9F9F9] shadow-2xl transition-transform duration-300 ease-in-out flex flex-col ${
            isMobileMenuOpen ? "translate-x-0" : "-translate-x-full"
          }`}
        >
          <div className="p-6 flex justify-between items-center border-b border-gray-200">
            <Menu className="w-6 h-6 text-gray-400" />
            <X
              className="w-6 h-6 cursor-pointer hover:text-gray-500"
              onClick={() => setIsMobileMenuOpen(false)}
            />
          </div>
          <div className="flex flex-col py-4 px-8 space-y-6 flex-grow">
            <button
              onClick={goToHome}
              className="text-left text-sm tracking-widest font-medium uppercase border-b border-gray-200 pb-4"
            >
              inicio
            </button>
            <button
              onClick={() => {
                setActivePage("conocenos");
                setIsMobileMenuOpen(false);
              }}
              className="text-left text-sm tracking-widest font-medium uppercase border-b border-gray-200 pb-4"
            >
              conocenos
            </button>
            <button
              onClick={goToMarcas}
              className="text-left text-sm tracking-widest font-medium uppercase border-b border-gray-200 pb-4"
            >
              marcas
            </button>
            <button
              onClick={() => {
                setActivePage("contactanos");
                setIsMobileMenuOpen(false);
              }}
              className="text-left text-sm tracking-widest font-medium uppercase border-b border-gray-200 pb-4"
            >
              contactanos
            </button>
          </div>
        </div>
      </div>

      {}
      <div className="flex-grow flex flex-col">
        {/* HOME PAGE */}
        {activePage === "home" ? (
          <main className="w-full flex-grow animate-in fade-in duration-500 flex flex-col">
            <div className="w-full bg-[#FAFAFA] border-b border-gray-100">
              <div className="max-w-[1400px] mx-auto flex flex-col md:flex-row items-stretch">
                <div className="w-full md:w-1/2 p-10 md:p-20 lg:p-24 flex flex-col justify-center items-center md:items-start text-center md:text-left z-10 min-h-[50vh] md:min-h-[600px]">
                  <h2 className="text-5xl md:text-6xl lg:text-7xl font-normal text-gray-900 mb-8 leading-[1.1] tracking-tight">
                    Exclusividad en
                    <br />
                    cada paso.
                  </h2>
                  <button
                    onClick={() => {
                      setActivePage("marcas");
                      window.scrollTo(0, 0);
                    }}
                    className="bg-[#111] text-white px-10 py-4 text-xs font-bold tracking-[0.2em] uppercase hover:bg-gray-800 transition-colors"
                  >
                    Ver Marcas
                  </button>
                </div>
                <div className="w-full md:w-1/2 bg-[#f4f4f4] h-[50vh] md:h-auto min-h-[600px] relative flex items-center justify-center overflow-hidden">
                  <img
                    src="https://i.postimg.cc/RVwhgKjR/IMG-4662.jpg"
                    referrerPolicy="no-referrer"
                    alt="Sneakers destacados"
                    className="w-full h-full object-cover object-center drop-shadow-2xl scale-110 md:scale-125 hover:scale-110 transition-transform duration-700"
                  />
                </div>
              </div>
            </div>

            <div className="w-full bg-white py-16 border-b border-gray-100 overflow-hidden relative">
              <h3 className="text-xl md:text-2xl font-medium text-center mb-12 text-black tracking-tight">
                Elige tu estilo, elige tu marca
              </h3>
              <div className="flex w-full overflow-hidden relative">
                <div className="absolute left-0 top-0 bottom-0 w-16 md:w-32 bg-gradient-to-r from-white to-transparent z-10 pointer-events-none"></div>
                <div className="absolute right-0 top-0 bottom-0 w-16 md:w-32 bg-gradient-to-l from-white to-transparent z-10 pointer-events-none"></div>
                <div className="animate-marquee items-center pl-16">
                  {[...Array(2)].map((_, i) => (
                    <div
                      key={i}
                      className="flex items-center gap-16 sm:gap-24 px-8"
                    >
                      {MARQUEE_LOGOS.map((logo, idx) => (
                        <div
                          key={`${i}-${idx}`}
                          onClick={() => goToBrand(logo.brand)}
                          className="cursor-pointer grayscale opacity-70 hover:grayscale-0 hover:opacity-100 hover:scale-110 transition-all duration-300 flex-shrink-0 flex items-center justify-center h-16 w-36"
                        >
                          {logo.img ? (
                            <img
                              src={logo.img}
                              alt={logo.brand}
                              className="h-full w-full object-contain"
                            />
                          ) : (
                            <span className="text-xl font-black tracking-tighter uppercase text-black">
                              {logo.brand}
                            </span>
                          )}
                        </div>
                      ))}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="w-full bg-[#f6f6f6] py-24">
              <div className="max-w-[1400px] mx-auto px-6 flex flex-col lg:flex-row gap-16">
                <div className="w-full lg:w-1/3">
                  <h2 className="text-4xl md:text-5xl font-medium text-[#1a4f44] tracking-tight leading-tight sticky top-24">
                    ¿Tienes dudas? Aquí resolvemos todo
                  </h2>
                </div>
                <div className="w-full lg:w-2/3 flex flex-col gap-4">
                  {faqs.map((faq, idx) => (
                    <div
                      key={idx}
                      className="bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow"
                    >
                      <button
                        onClick={() => setOpenFaq(openFaq === idx ? null : idx)}
                        className="w-full px-6 py-5 flex justify-between items-center text-left"
                      >
                        <span className="text-[#1a4f44] font-medium text-lg">
                          {faq.q}
                        </span>
                        <ChevronDown
                          className={`w-5 h-5 text-[#1a4f44] transition-transform duration-300 ${
                            openFaq === idx ? "rotate-180" : ""
                          }`}
                        />
                      </button>
                      <div
                        className={`px-6 overflow-hidden transition-all duration-300 ease-in-out ${
                          openFaq === idx
                            ? "max-h-40 pb-5 opacity-100"
                            : "max-h-0 opacity-0"
                        }`}
                      >
                        <p className="text-gray-600 leading-relaxed">{faq.a}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </main>
        ) : activePage === "conocenos" ? (
          <main className="w-full flex-grow py-28 px-6 relative animate-in fade-in duration-500 flex items-center justify-center overflow-hidden bg-texture-dots">
            <div className="max-w-3xl mx-auto text-center space-y-10 relative z-10 bg-white/90 backdrop-blur-sm p-12 border border-gray-200 shadow-xl">
              <h2 className="text-3xl md:text-4xl font-light tracking-widest uppercase text-black">
                ¿Qué es SNEAKERSHEADS?
              </h2>
              <p className="text-gray-600 leading-relaxed font-light text-lg">
                En <strong>sneakersheads</strong> hacemos las cosas distinto.
                Filtramos el ruido de la calle para traerte esos pares que todos
                buscan pero muy pocos consiguen. Sabemos que un buen par de
                sneakers no es solo un accesorio, es una declaración de
                identidad.
              </p>
              <p className="text-gray-600 leading-relaxed font-light text-lg">
                Si buscas elevar tu rotación, romper esquemas y llevar tu outfit
                al siguiente nivel, estás en el lugar correcto. Tu estilo es tu
                voz; nosotros solo le subimos el volumen.
              </p>
            </div>
          </main>
        ) : activePage === "marcas" ? (
          <main className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-in slide-in-from-bottom-4 duration-500 flex-grow w-full">
            {!activeBrand && !searchQuery ? (
              <>
                <h2 className="text-3xl font-light text-center mb-16 tracking-widest uppercase mt-8">
                  Todas las marcas
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-1">
                  {BRANDS.map((brand) => (
                    <div
                      key={brand}
                      onClick={() => setActiveBrand(brand)}
                      className="group relative aspect-square bg-gray-100 cursor-pointer overflow-hidden flex items-center justify-center"
                    >
                      <div className="absolute inset-0 bg-black/60 z-10 transition-colors group-hover:bg-black/40"></div>
                      <img
                        src="https://images.unsplash.com/photo-1617141636415-77989d4948eb?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
                        alt={brand}
                        className="absolute inset-0 w-full h-full object-cover grayscale transition-transform duration-700 group-hover:scale-110"
                      />
                      <h3 className="relative z-20 text-white text-2xl font-medium tracking-[0.2em] uppercase">
                        {brand}
                      </h3>
                    </div>
                  ))}
                </div>
              </>
            ) : (
              <div className="flex flex-col w-full">
                <div className="text-center pb-10 pt-4">
                  <h2 className="text-4xl md:text-5xl font-light tracking-[0.2em] uppercase text-black">
                    {searchQuery
                      ? `Resultados para "${searchQuery}"`
                      : activeBrand}
                  </h2>
                </div>

                <div className="flex justify-between items-center border-y border-gray-200 py-4 mb-10 text-[10px] sm:text-xs font-bold tracking-widest uppercase text-gray-500 relative">
                  <div className="w-1/3 flex justify-start">
                    <button
                      className="lg:hidden flex items-center gap-2 text-black hover:text-gray-600"
                      onClick={() => setIsFilterMenuOpen(true)}
                    >
                      <SlidersHorizontal className="w-4 h-4" /> Filtrar
                    </button>
                  </div>

                  <div className="w-1/3 flex justify-center text-center">
                    <span>{getFilteredProducts().length} productos</span>
                  </div>

                  <div className="w-1/3 flex justify-end relative">
                    <button
                      onClick={() =>
                        setIsFilterDropdownOpen(!isFilterDropdownOpen)
                      }
                      className="flex items-center gap-2 hover:text-black transition-colors"
                    >
                      Ordenar por
                      <ChevronDown
                        className={`w-4 h-4 transition-transform ${
                          isFilterDropdownOpen ? "rotate-180" : ""
                        }`}
                      />
                    </button>

                    {isFilterDropdownOpen && (
                      <div className="absolute top-full right-0 mt-4 w-48 bg-white border border-gray-200 shadow-2xl z-30 py-2 animate-in fade-in zoom-in-95 text-left">
                        <div className="flex flex-col text-xs font-medium normal-case tracking-normal text-gray-600">
                          <button
                            onClick={() => {
                              setSortBy("price_desc");
                              setIsFilterDropdownOpen(false);
                            }}
                            className={`text-left px-4 py-3 hover:bg-gray-50 transition-colors ${
                              sortBy === "price_desc"
                                ? "font-bold text-black"
                                : ""
                            }`}
                          >
                            Precio, mayor a menor
                          </button>
                          <button
                            onClick={() => {
                              setSortBy("price_asc");
                              setIsFilterDropdownOpen(false);
                            }}
                            className={`text-left px-4 py-3 hover:bg-gray-50 transition-colors ${
                              sortBy === "price_asc"
                                ? "font-bold text-black"
                                : ""
                            }`}
                          >
                            Precio, menor a mayor
                          </button>
                          <button
                            onClick={() => {
                              setSortBy("available");
                              setIsFilterDropdownOpen(false);
                            }}
                            className={`text-left px-4 py-3 hover:bg-gray-50 transition-colors ${
                              sortBy === "available"
                                ? "font-bold text-black"
                                : ""
                            }`}
                          >
                            Disponibilidad
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex flex-col lg:flex-row gap-12 items-start">
                  <div className="hidden lg:block w-1/4 max-w-[280px] sticky top-28 flex-shrink-0 pr-8 border-r border-gray-100 min-h-[50vh]">
                    <h3 className="text-sm font-bold tracking-widest uppercase mb-4 text-black">
                      Filtros
                    </h3>
                    <FilterAccordion
                      title="Color"
                      options={availableColors}
                      selected={selectedColors}
                      onChange={(val) =>
                        handleToggleFilter(
                          setSelectedColors,
                          selectedColors,
                          val
                        )
                      }
                    />
                    <FilterAccordion
                      title="Género"
                      options={availableGenders}
                      selected={selectedGenders}
                      onChange={(val) =>
                        handleToggleFilter(
                          setSelectedGenders,
                          selectedGenders,
                          val
                        )
                      }
                    />
                    <FilterAccordion
                      title="Estilo"
                      options={availableStyles}
                      selected={selectedStyles}
                      onChange={(val) =>
                        handleToggleFilter(
                          setSelectedStyles,
                          selectedStyles,
                          val
                        )
                      }
                    />
                  </div>

                  <div className="w-full lg:w-3/4">
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-x-4 gap-y-10 sm:gap-x-6 sm:gap-y-16">
                      {getFilteredProducts().map((product) => (
                        <div
                          key={product.id}
                          className="group cursor-pointer flex flex-col relative"
                          onClick={() => setSelectedProduct(product)}
                        >
                          <div className="relative aspect-square bg-[#f4f4f4] mb-4 overflow-hidden flex items-center justify-center p-6 sm:p-10">
                            {product.status === "sold_out" && (
                              <div className="absolute top-4 right-4 bg-black text-white text-[10px] font-bold tracking-widest uppercase px-3 py-1 z-10">
                                Agotado
                              </div>
                            )}
                            <img
                              src={product.image}
                              onError={handleImgError}
                              alt={product.name}
                              referrerPolicy="no-referrer"
                              className={`w-full h-full object-contain mix-blend-multiply transition-transform duration-500 group-hover:scale-110 ${
                                product.status === "sold_out"
                                  ? "opacity-50 grayscale"
                                  : ""
                              }`}
                            />
                          </div>
                          <p className="text-[10px] text-gray-500 font-bold uppercase tracking-[0.2em] mb-1">
                            {product.brand}
                          </p>
                          <h3 className="text-sm sm:text-base font-medium leading-tight mb-2 pr-4">
                            {product.name}
                          </h3>
                          <p className="text-sm font-bold mt-auto">
                            ${product.price.toLocaleString("es-MX")} MXN
                          </p>
                        </div>
                      ))}
                      {getFilteredProducts().length === 0 && (
                        <div className="col-span-full py-20 text-center text-gray-500 text-sm tracking-widest uppercase border border-dashed border-gray-300">
                          No se encontraron modelos con estos filtros o
                          búsqueda.
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </main>
        ) : activePage === "contactanos" ? (
          <main className="w-full flex-grow py-24 px-6 relative animate-in fade-in duration-500 flex items-center justify-center overflow-hidden bg-texture-dots">
            <div className="max-w-3xl w-full mx-auto text-center space-y-12 relative z-10 bg-white/90 backdrop-blur-sm p-12 border border-gray-200 shadow-xl">
              <h2 className="text-3xl md:text-4xl font-light tracking-widest uppercase text-black">
                Contáctanos
              </h2>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-4">
                <div
                  onClick={() => window.open(whatsappHelpUrl, "_blank")}
                  className="flex flex-col items-center justify-center p-8 border border-gray-100 bg-white hover:border-black transition-colors cursor-pointer group"
                >
                  <WhatsAppIcon className="w-8 h-8 mb-4 text-black group-hover:scale-110 transition-transform" />
                  <h3 className="text-xs font-bold uppercase tracking-widest mb-2">
                    WhatsApp
                  </h3>
                  <p className="text-sm text-gray-500 font-light">
                    +52 646 199 7001
                  </p>
                </div>

                <div
                  onClick={() => window.open("mailto:contact@sneakersheads.mx")}
                  className="flex flex-col items-center justify-center p-8 border border-gray-100 bg-white hover:border-black transition-colors cursor-pointer group"
                >
                  <Mail className="w-8 h-8 mb-4 text-black group-hover:scale-110 transition-transform" />
                  <h3 className="text-xs font-bold uppercase tracking-widest mb-2">
                    Correo
                  </h3>
                  <p className="text-sm text-gray-500 font-light">
                    contact@sneakersheads.mx
                  </p>
                </div>

                <div
                  onClick={() =>
                    window.open(
                      "https://instagram.com/sneakersheads.mx",
                      "_blank"
                    )
                  }
                  className="flex flex-col items-center justify-center p-8 border border-gray-100 bg-white hover:border-black transition-colors cursor-pointer group"
                >
                  <Instagram className="w-8 h-8 mb-4 text-black group-hover:scale-110 transition-transform" />
                  <h3 className="text-xs font-bold uppercase tracking-widest mb-2">
                    Instagram
                  </h3>
                  <p className="text-sm text-gray-500 font-light">
                    @sneakersheads.mx
                  </p>
                </div>
              </div>
            </div>
          </main>
        ) : activePage === "checkout" ? (
          <main className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 py-12 animate-in slide-in-from-right-8 duration-500 w-full flex-grow">
            <button
              onClick={() => {
                setActivePage("home");
                setIsCartOpen(true);
              }}
              className="text-xs font-bold uppercase tracking-widest text-gray-400 hover:text-black flex items-center gap-2 mb-8"
            >
              &larr; Volver al Carrito
            </button>
            <div className="flex flex-col lg:flex-row gap-12">
              {isCheckingOut ? (
                <div className="w-full h-[60vh] flex flex-col items-center justify-center space-y-6">
                  <div className="w-16 h-16 border-4 border-gray-200 border-t-black rounded-full animate-spin"></div>
                  <h2 className="text-2xl font-light uppercase tracking-widest text-center">
                    Procesando tu pedido...
                  </h2>
                  <p className="text-gray-500 text-sm">
                    Conectando pasarelas de pago de alta seguridad
                  </p>
                </div>
              ) : paymentSuccess ? (
                <div className="w-full h-[60vh] flex flex-col items-center justify-center space-y-6 animate-in zoom-in">
                  <div className="w-20 h-20 bg-green-50 rounded-full flex items-center justify-center">
                    <Check className="w-10 h-10 text-green-500" />
                  </div>
                  <h2 className="text-3xl font-black uppercase tracking-tighter text-center">
                    ¡Pedido Confirmado!
                  </h2>
                  <p className="text-gray-500 text-center max-w-md">
                    Tu pedido ha sido procesado exitosamente. En breve recibirás
                    los detalles de seguimiento.
                  </p>
                </div>
              ) : (
                <>
                  <div className="w-full lg:w-3/5">
                    <h2 className="text-2xl font-black uppercase tracking-tighter mb-8">
                      Finalizar Compra
                    </h2>
                    <form onSubmit={handleCheckout} className="space-y-10">
                      {/* 1. Datos de Contacto */}
                      <div className="space-y-6">
                        <h3 className="text-sm font-bold uppercase tracking-widest border-b pb-2 text-gray-400">
                          1. Datos de Contacto
                        </h3>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <input
                            required
                            name="firstName"
                            type="text"
                            placeholder="Nombre(s)"
                            className="w-full bg-white border border-gray-200 p-4 text-sm focus:outline-none focus:border-black transition-colors"
                          />
                          <input
                            required
                            name="lastName"
                            type="text"
                            placeholder="Apellidos"
                            className="w-full bg-white border border-gray-200 p-4 text-sm focus:outline-none focus:border-black transition-colors"
                          />
                          <input
                            required
                            name="email"
                            type="email"
                            placeholder="Correo Electrónico"
                            className="sm:col-span-2 w-full bg-white border border-gray-200 p-4 text-sm focus:outline-none focus:border-black transition-colors"
                          />
                          <input
                            required
                            name="phone"
                            type="tel"
                            placeholder="Teléfono (10 dígitos)"
                            value={phoneNum}
                            onChange={(e) =>
                              setPhoneNum(
                                e.target.value.replace(/\D/g, "").slice(0, 10)
                              )
                            }
                            className="sm:col-span-2 w-full bg-white border border-gray-200 p-4 text-sm focus:outline-none focus:border-black transition-colors"
                          />
                        </div>
                      </div>

                      {/* 2. Método de Entrega */}
                      <div className="space-y-6">
                        <h3 className="text-sm font-bold uppercase tracking-widest border-b pb-2 text-gray-400">
                          2. Método de Entrega
                        </h3>
                        <div className="grid grid-cols-2 gap-4">
                          <label
                            className={`flex flex-col items-center justify-center p-6 border cursor-pointer transition-colors ${
                              shippingMethod === "delivery"
                                ? "border-black bg-gray-50"
                                : "border-gray-200 bg-white"
                            }`}
                          >
                            <input
                              type="radio"
                              name="shipping"
                              checked={shippingMethod === "delivery"}
                              onChange={() => setShippingMethod("delivery")}
                              className="sr-only"
                            />
                            <Truck className="w-6 h-6 mb-2" />
                            <span className="text-xs font-bold uppercase tracking-widest text-center">
                              A Domicilio
                            </span>
                          </label>
                          <label
                            className={`flex flex-col items-center justify-center p-6 border cursor-pointer transition-colors ${
                              shippingMethod === "personal"
                                ? "border-black bg-gray-50"
                                : "border-gray-200 bg-white"
                            }`}
                          >
                            <input
                              type="radio"
                              name="shipping"
                              checked={shippingMethod === "personal"}
                              onChange={() => setShippingMethod("personal")}
                              className="sr-only"
                            />
                            <MapPin className="w-6 h-6 mb-2" />
                            <span className="text-xs font-bold uppercase tracking-widest text-center">
                              Entrega Personal
                            </span>
                          </label>
                        </div>

                        {shippingMethod === "delivery" ? (
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 animate-in fade-in duration-300">
                            <input
                              required
                              name="street"
                              type="text"
                              placeholder="Calle y Número (Ext / Int)"
                              className="sm:col-span-2 w-full bg-white border border-gray-200 p-4 text-sm focus:outline-none focus:border-black transition-colors"
                            />
                            <input
                              required
                              name="colony"
                              type="text"
                              placeholder="Colonia / Fraccionamiento"
                              className="w-full bg-white border border-gray-200 p-4 text-sm focus:outline-none focus:border-black transition-colors"
                            />
                            <input
                              required
                              name="zip"
                              type="text"
                              inputMode="numeric"
                              placeholder="Código Postal (5 dígitos)"
                              value={zipCode}
                              onChange={(e) =>
                                setZipCode(
                                  e.target.value.replace(/\D/g, "").slice(0, 5)
                                )
                              }
                              className="w-full bg-white border border-gray-200 p-4 text-sm focus:outline-none focus:border-black transition-colors"
                            />
                            <div>
                              <input
                                required
                                name="state"
                                list="mexico-states"
                                value={selectedState}
                                onChange={(e) => {
                                  setSelectedState(e.target.value);
                                  setSelectedCity("");
                                }}
                                placeholder="Selecciona o escribe tu Estado"
                                className="w-full bg-white border border-gray-200 p-4 text-sm focus:outline-none focus:border-black transition-colors"
                              />
                              <datalist id="mexico-states">
                                {MEXICO_STATES.map((st) => (
                                  <option key={st} value={st} />
                                ))}
                              </datalist>
                            </div>
                            <div>
                              <input
                                required
                                name="city"
                                list="mexico-cities"
                                value={selectedCity}
                                onChange={(e) =>
                                  setSelectedCity(e.target.value)
                                }
                                placeholder={
                                  selectedState
                                    ? `Municipio / Ciudad (${selectedState})`
                                    : "Ciudad o Municipio"
                                }
                                className="w-full bg-white border border-gray-200 p-4 text-sm focus:outline-none focus:border-black transition-colors"
                              />
                              <datalist id="mexico-cities">
                                {getCitiesForSelectedState().map((city) => (
                                  <option key={city} value={city} />
                                ))}
                              </datalist>
                            </div>
                          </div>
                        ) : (
                          <div className="bg-gray-50 border border-gray-200 p-4 text-xs text-gray-600 leading-relaxed animate-in fade-in duration-300">
                            🤝 Al confirmar tu pedido te redirigiremos a nuestro{" "}
                            <strong>WhatsApp Oficial</strong> para acordar el
                            punto y horario de entrega personal.
                          </div>
                        )}
                      </div>

                      {/* 3. Método de Pago */}
                      <div className="space-y-6">
                        <h3 className="text-sm font-bold uppercase tracking-widest border-b pb-2 text-gray-400">
                          3. Pago
                        </h3>
                        <div className="flex flex-col gap-3">
                          <label
                            className={`flex items-center justify-between p-4 border cursor-pointer transition-colors ${
                              paymentMethod === "card"
                                ? "border-black bg-gray-50"
                                : "border-gray-200 bg-white"
                            }`}
                          >
                            <div className="flex items-center gap-3">
                              <input
                                type="radio"
                                name="payment"
                                checked={paymentMethod === "card"}
                                onChange={() => setPaymentMethod("card")}
                                className="accent-black w-4 h-4"
                              />
                              <span className="text-sm font-medium">
                                Tarjeta de Crédito / Débito
                              </span>
                            </div>
                            <CreditCard className="w-5 h-5 text-gray-600" />
                          </label>

                          {paymentMethod === "card" && (
                            <div className="p-5 border border-gray-200 bg-gray-50/60 space-y-4 animate-in fade-in duration-300">
                              <input
                                required
                                type="text"
                                placeholder="Titular de la tarjeta (Como aparece en el plástico)"
                                value={cardName}
                                onChange={(e) =>
                                  setCardName(
                                    e.target.value.replace(
                                      /[^a-zA-ZáéíóúÁÉÍÓÚñÑ\s]/g,
                                      ""
                                    )
                                  )
                                }
                                className="w-full bg-white border border-gray-200 p-4 text-sm focus:outline-none focus:border-black"
                              />
                              <input
                                required
                                type="text"
                                inputMode="numeric"
                                placeholder="Número de Tarjeta (16 dígitos)"
                                value={cardNumber}
                                onChange={(e) => {
                                  const raw = e.target.value
                                    .replace(/\D/g, "")
                                    .slice(0, 16);
                                  const formatted = raw.replace(
                                    /(\d{4})(?=\d)/g,
                                    "$1 "
                                  );
                                  setCardNumber(formatted);
                                }}
                                className="w-full bg-white border border-gray-200 p-4 text-sm focus:outline-none focus:border-black tracking-widest"
                              />
                              <div className="grid grid-cols-2 gap-4">
                                <input
                                  required
                                  type="text"
                                  inputMode="numeric"
                                  placeholder="MM/AA"
                                  value={cardExpiry}
                                  onChange={(e) => {
                                    const raw = e.target.value
                                      .replace(/\D/g, "")
                                      .slice(0, 4);
                                    if (raw.length >= 3) {
                                      setCardExpiry(
                                        `${raw.slice(0, 2)}/${raw.slice(2)}`
                                      );
                                    } else {
                                      setCardExpiry(raw);
                                    }
                                  }}
                                  className="w-full bg-white border border-gray-200 p-4 text-sm focus:outline-none focus:border-black text-center tracking-widest"
                                />
                                <input
                                  required
                                  type="password"
                                  inputMode="numeric"
                                  placeholder="CVV (3 o 4 dígitos)"
                                  value={cardCvv}
                                  onChange={(e) =>
                                    setCardCvv(
                                      e.target.value
                                        .replace(/\D/g, "")
                                        .slice(0, 4)
                                    )
                                  }
                                  className="w-full bg-white border border-gray-200 p-4 text-sm focus:outline-none focus:border-black text-center tracking-widest"
                                />
                              </div>
                              <div className="flex items-center gap-2 text-[11px] text-gray-500 pt-1">
                                <Lock className="w-3.5 h-3.5 text-green-600" />
                                <span>
                                  Transacción encriptada de extremo a extremo
                                  con seguridad SSL.
                                </span>
                              </div>
                            </div>
                          )}

                          <label
                            className={`flex items-center justify-between p-4 border cursor-pointer transition-colors ${
                              paymentMethod === "paypal"
                                ? "border-black bg-gray-50"
                                : "border-gray-200 bg-white"
                            }`}
                          >
                            <div className="flex items-center gap-3">
                              <input
                                type="radio"
                                name="payment"
                                checked={paymentMethod === "paypal"}
                                onChange={() => setPaymentMethod("paypal")}
                                className="accent-black w-4 h-4"
                              />
                              <span className="text-sm font-medium">
                                PayPal
                              </span>
                            </div>
                            <span className="text-[10px] font-bold uppercase tracking-widest text-gray-400">
                              Pago Seguro
                            </span>
                          </label>

                          {shippingMethod === "personal" && (
                            <label
                              className={`flex items-center justify-between p-4 border cursor-pointer transition-colors ${
                                paymentMethod === "cash"
                                  ? "border-black bg-gray-50"
                                  : "border-gray-200 bg-white"
                              }`}
                            >
                              <div className="flex items-center gap-3">
                                <input
                                  type="radio"
                                  name="payment"
                                  checked={paymentMethod === "cash"}
                                  onChange={() => setPaymentMethod("cash")}
                                  className="accent-black w-4 h-4"
                                />
                                <span className="text-sm font-medium">
                                  Efectivo (Pago contra entrega)
                                </span>
                              </div>
                              <span className="text-[10px] font-bold uppercase tracking-widest text-green-600">
                                Disponible
                              </span>
                            </label>
                          )}
                        </div>
                      </div>

                      <button
                        type="submit"
                        className="w-full bg-black text-white py-5 text-xs font-bold tracking-[0.2em] uppercase hover:bg-gray-800 transition-colors flex justify-center items-center gap-2 shadow-xl shadow-black/10"
                      >
                        Pagar ${finalTotal.toLocaleString("es-MX")} MXN{" "}
                        <ArrowRight className="w-4 h-4" />
                      </button>
                    </form>
                  </div>

                  <div className="w-full lg:w-2/5">
                    <div className="bg-white border border-gray-200 p-6 sticky top-28 shadow-sm">
                      <h3 className="text-sm font-bold uppercase tracking-widest border-b pb-4 mb-4 text-gray-900">
                        Resumen del Pedido
                      </h3>
                      <div className="space-y-4 mb-6 max-h-[40vh] overflow-y-auto pr-2 custom-scrollbar">
                        {cart.map((item, idx) => (
                          <div key={idx} className="flex gap-4 items-center">
                            <div className="w-20 h-20 bg-[#f4f4f4] flex-shrink-0 flex items-center justify-center p-2 border border-gray-100">
                              <img
                                src={item.image}
                                onError={handleImgError}
                                alt={item.name}
                                referrerPolicy="no-referrer"
                                className="w-full h-full object-contain mix-blend-multiply"
                              />
                            </div>
                            <div className="flex-1">
                              <h4 className="text-[10px] font-bold uppercase tracking-widest text-gray-500">
                                {item.brand}
                              </h4>
                              <p className="text-xs text-gray-900 mt-0.5 font-medium leading-tight">
                                {item.name}
                              </p>
                              <p className="text-[10px] text-gray-500 mt-1">
                                Talla: {item.selectedSize} MX
                              </p>
                            </div>
                            <p className="text-sm font-bold">
                              ${item.price.toLocaleString("es-MX")}
                            </p>
                          </div>
                        ))}
                      </div>
                      <div className="space-y-3 text-sm border-t pt-4 border-gray-100 text-gray-600">
                        <div className="flex justify-between">
                          <span>Subtotal</span>
                          <span>${subtotal.toLocaleString("es-MX")} MXN</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Envío</span>
                          <span>
                            {shippingCost === 0
                              ? "GRATIS"
                              : `$${shippingCost.toLocaleString("es-MX")} MXN`}
                          </span>
                        </div>
                        {shippingMethod === "delivery" && subtotal < 5000 && (
                          <p className="text-[11px] text-gray-400">
                            Envío gratis en pedidos superiores a $5,000 MXN
                          </p>
                        )}
                        <div className="flex justify-between text-xl font-bold pt-4 border-t border-gray-200 text-black mt-4">
                          <span>Total</span>
                          <span>${finalTotal.toLocaleString("es-MX")} MXN</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </>
              )}
            </div>
          </main>
        ) : null}
      </div>

      {}
      <div
        className={`fixed inset-0 z-50 lg:hidden transition-opacity duration-300 ${
          isFilterMenuOpen ? "opacity-100 visible" : "opacity-0 invisible"
        }`}
      >
        <div
          className="absolute inset-0 bg-black/60 backdrop-blur-sm"
          onClick={() => setIsFilterMenuOpen(false)}
        />
        <div
          className={`absolute top-0 left-0 bottom-0 w-[85%] max-w-sm bg-white shadow-2xl transition-transform duration-300 ease-in-out flex flex-col ${
            isFilterMenuOpen ? "translate-x-0" : "-translate-x-full"
          }`}
        >
          <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-white">
            <h2 className="text-sm font-bold tracking-widest uppercase text-black flex items-center gap-2">
              <SlidersHorizontal className="w-4 h-4" /> Filtros
            </h2>
            <X
              className="w-5 h-5 cursor-pointer hover:text-gray-500"
              onClick={() => setIsFilterMenuOpen(false)}
            />
          </div>
          <div className="flex-1 overflow-y-auto px-6 py-2 flex flex-col">
            <FilterAccordion
              title="Color"
              options={availableColors}
              selected={selectedColors}
              onChange={(val) =>
                handleToggleFilter(setSelectedColors, selectedColors, val)
              }
            />
            <FilterAccordion
              title="Género"
              options={availableGenders}
              selected={selectedGenders}
              onChange={(val) =>
                handleToggleFilter(setSelectedGenders, selectedGenders, val)
              }
            />
            <FilterAccordion
              title="Estilo"
              options={availableStyles}
              selected={selectedStyles}
              onChange={(val) =>
                handleToggleFilter(setSelectedStyles, selectedStyles, val)
              }
            />
          </div>
          <div className="p-6 border-t border-gray-100 bg-white">
            <button
              onClick={() => setIsFilterMenuOpen(false)}
              className="w-full bg-black text-white py-4 text-xs font-bold tracking-[0.2em] uppercase hover:bg-gray-800 transition-colors"
            >
              Aplicar ({getFilteredProducts().length} resultados)
            </button>
          </div>
        </div>
      </div>

      {/* FOOTER */}
      <footer className="w-full bg-[#f4f4f4] border-t border-gray-200 py-12 flex justify-center items-center gap-10">
        <WhatsAppIcon
          className="w-6 h-6 text-black cursor-pointer hover:scale-110 transition-transform"
          onClick={() => window.open(whatsappHelpUrl, "_blank")}
        />
        <Instagram
          className="w-6 h-6 text-black cursor-pointer hover:scale-110 transition-transform"
          onClick={() =>
            window.open("https://instagram.com/sneakersheads.mx", "_blank")
          }
        />
        <Mail
          className="w-6 h-6 text-black cursor-pointer hover:scale-110 transition-transform"
          onClick={() => setActivePage("contactanos")}
        />
      </footer>

      {}
      <div
        className={`fixed inset-0 z-50 transition-opacity duration-300 ${
          isCartOpen ? "opacity-100 visible" : "opacity-0 invisible"
        }`}
      >
        <div
          className="absolute inset-0 bg-black/60 backdrop-blur-sm"
          onClick={() => setIsCartOpen(false)}
        />
        <div
          className={`absolute top-0 right-0 bottom-0 w-[90%] max-w-md bg-white shadow-2xl transition-transform duration-300 ease-in-out flex flex-col ${
            isCartOpen ? "translate-x-0" : "translate-x-full"
          }`}
        >
          <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-white">
            <h2 className="text-sm font-bold tracking-widest uppercase">
              Carrito ({cart.length})
            </h2>
            <X
              className="w-5 h-5 cursor-pointer hover:text-gray-500"
              onClick={() => setIsCartOpen(false)}
            />
          </div>
          <div className="flex-1 overflow-y-auto p-6 flex flex-col gap-6">
            {cart.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-gray-400 gap-4">
                <ShoppingBag className="w-12 h-12 opacity-20" />
                <p className="text-xs font-bold uppercase tracking-widest">
                  Tu carrito está vacío
                </p>
                <button
                  onClick={() => {
                    setIsCartOpen(false);
                    goToMarcas();
                  }}
                  className="mt-4 border-b border-black text-black text-xs font-bold uppercase tracking-widest pb-1"
                >
                  Explorar Stock
                </button>
              </div>
            ) : (
              cart.map((item, index) => (
                <div key={index} className="flex gap-4 bg-white">
                  <div className="w-24 h-24 bg-[#f4f4f4] flex-shrink-0 flex items-center justify-center p-2">
                    <img
                      src={item.image}
                      onError={handleImgError}
                      alt={item.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-contain mix-blend-multiply"
                    />
                  </div>
                  <div className="flex-1 flex flex-col justify-between py-1">
                    <div>
                      <div className="flex justify-between items-start">
                        <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">
                          {item.brand}
                        </p>
                        <button
                          onClick={() => removeFromCart(index)}
                          className="text-gray-400 hover:text-black"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                      <h4 className="text-sm font-medium leading-tight mt-1">
                        {item.name}
                      </h4>
                      <p className="text-xs text-gray-500 mt-1">
                        Talla: {item.selectedSize} MX
                      </p>
                    </div>
                    <p className="text-sm font-bold">
                      ${item.price.toLocaleString("es-MX")} MXN
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>
          {cart.length > 0 && (
            <div className="p-6 border-t border-gray-100 bg-white space-y-6 shadow-[0_-10px_40px_rgba(0,0,0,0.05)] relative z-10">
              <div className="flex justify-between items-end">
                <span className="text-xs text-gray-500 uppercase tracking-widest">
                  Subtotal
                </span>
                <span className="text-2xl font-bold">
                  ${subtotal.toLocaleString("es-MX")} MXN
                </span>
              </div>
              <button
                onClick={goToCheckout}
                className="w-full bg-black text-white py-4 text-xs font-bold tracking-[0.2em] uppercase hover:bg-gray-800 transition-colors flex justify-center items-center gap-2"
              >
                Proceder al Pago <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* PRODUCT MODAL */}
      {selectedProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setSelectedProduct(null)}
          />
          <div className="relative bg-white w-full max-w-4xl max-h-[90vh] overflow-y-auto flex flex-col md:flex-row animate-in fade-in zoom-in-95 duration-200">
            <button
              onClick={() => setSelectedProduct(null)}
              className="absolute top-4 right-4 z-10 p-2 bg-white/80 hover:bg-black hover:text-white transition-colors rounded-full"
            >
              <X className="w-5 h-5" />
            </button>
            <div className="w-full md:w-1/2 bg-[#f4f4f4] flex items-center justify-center p-8">
              <img
                src={selectedProduct.image}
                onError={handleImgError}
                alt={selectedProduct.name}
                referrerPolicy="no-referrer"
                className="w-full h-auto object-contain mix-blend-multiply"
              />
            </div>
            <div className="w-full md:w-1/2 p-8 md:p-12 flex flex-col justify-center">
              <p className="text-[10px] text-gray-500 font-bold uppercase tracking-[0.2em] mb-2">
                {selectedProduct.brand}
              </p>
              <h3 className="text-3xl font-light leading-tight mb-4">
                {selectedProduct.name}
              </h3>
              <p className="text-2xl font-bold mb-8">
                ${selectedProduct.price.toLocaleString("es-MX")} MXN
              </p>
              <div className="mb-8">
                <div className="flex justify-between items-center mb-4">
                  <span className="text-xs font-bold uppercase tracking-widest">
                    Talla (MX)
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {SIZES_MX.map((size) => (
                    <button
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      className={`py-3 text-sm font-medium border transition-all ${
                        selectedSize === size
                          ? "border-black bg-black text-white"
                          : "border-gray-200 hover:border-black text-gray-900"
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>
              <button
                onClick={handleAddToCart}
                disabled={!selectedSize}
                className={`w-full py-4 text-xs font-bold tracking-[0.2em] uppercase transition-all ${
                  selectedSize
                    ? "bg-black text-white hover:bg-zinc-800"
                    : "bg-gray-100 text-gray-400 cursor-not-allowed"
                }`}
              >
                {selectedSize ? "Agregar al Carrito" : "Selecciona una talla"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* NOTIFICATION */}
      {notification && (
        <div className="fixed bottom-6 right-6 bg-black text-white px-6 py-4 text-xs font-bold tracking-widest shadow-2xl animate-in slide-in-from-bottom-5 fade-in z-50 flex items-center gap-3">
          <Check className="w-4 h-4 text-green-400" /> {notification}
        </div>
      )}
    </div>
  );
}
